# Compact access plans: exploratory follow-up

Started 23 November 2026 before execution of the new kernels. Preserve the
earlier WRAM pilot unchanged. This experiment investigates a candidate, not an
established novel contribution or a guaranteed improvement.

## Hypothesis

For repeated indexed aggregation with fixed connectivity, preparing WRAM slot
and load decisions once on the host can reduce DPU bookkeeping enough to make
retention useful. A plan replaces each 32-bit source index with one 32-bit
instruction: load flag, source index on misses, and WRAM byte offset. It keeps
input ordering, output arithmetic and index-stream size unchanged.

This is an inspector/executor approach. Offline caching, scratchpad allocation,
and Belady replacement are established techniques. The candidate contribution
would have to concern the UPMEM encoding, measured instruction/traffic trade-off,
and amortization boundary. Absence from a few papers is not novelty proof.

## Comparisons

- Streaming with 128- and 256-byte index buffering.
- Runtime direct-mapped history caching.
- An encoded plan with the **same direct-mapped decisions**, isolating lookup
  overhead from replacement quality.
- An encoded next-use plan using known input order (offline Belady replacement).
  Its full input knowledge is available only for exposed/repeated worklists.
- Planned LRU replacement as a simpler offline-planning control.

Use a common row-oriented reduction kernel for all policies. Retention receives
512 bytes/tasklet; all methods fit the same 64 KiB WRAM ceiling including the
upstream linker's reserved stacks. Start with four tasklets, then test twelve
tasklets before any recommendation. Keep all baselines and negative cases.

## Accounting and checks

Validate every output feature, exact MRAM read/write bytes and plan semantics.
For the direct-map pair, require identical feature-load counts. Count plan
storage and construction time. A plan replaces indices rather than adding a
second DPU stream. Fresh feature values must be loaded on each execution;
topology, processing order, tasklet partition or resource changes invalidate it.

Report complete DPU kernel cycles; separately derive the number of repeated
executions needed to amortize host planning. Host transfer/launch times are not
measured by this model and must remain explicit unknowns. Integer aggregation
does not demonstrate floating-point ML performance. Energy and GPU results
are outside this experiment.

Initial screening uses seed 7; held-out generated inputs use 23 and 61 only
after the implementation/selection rule is fixed. These are exploratory tests,
not a large confirmatory campaign. Include a small real graph-derived workload
if acquisition is straightforward. A sub-5% simulated benefit is mechanism
evidence, not a hardware deployment recommendation. No extra MRAM traffic is
the primary acceptance limit. No arbitrary tuning on held-out results.
